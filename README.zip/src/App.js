import React from 'react';


import RouterPage from './pages/Routerpage';

function App() {
  return (
    <div className="App">
         <RouterPage/>
    </div>
  );
}

export default App;
